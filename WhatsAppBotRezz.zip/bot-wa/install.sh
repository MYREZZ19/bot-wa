pkg install ffmpeg -y
pkg install libwebp -y
pkg install imagemagick -y
pkg install nodejs -y
pkg install tesseract -y
npm install